document.addEventListener('DOMContentLoaded', () => {
    let cart = [];
    const btnCart = document.querySelector('.container-icon');
    const containerCartProducts = document.querySelector('.container-cart-products');
    const countProducts = document.querySelector('#contador-productos');
    const btnAddToCart = document.querySelectorAll('.btn-add-cart');

    // Añadir productos al carrito
    btnAddToCart.forEach(btn => {
        btn.addEventListener('click', () => {
            const product = btn.closest('.item');
            const title = product.querySelector('h2').textContent;
            const price = product.querySelector('.price').textContent;

            cart.push({
                title,
                price,
                quantity: 1
            });

            updateCart();
        });
    });

    // Actualizar carrito
    const updateCart = () => {
        containerCartProducts.innerHTML = '';
        cart.forEach(product => {
            const cartProduct = document.createElement('div');
            cartProduct.classList.add('cart-product');
            cartProduct.innerHTML = `
                <p class="titulo-producto-carrito">${product.title}</p>
                <p class="precio-producto-carrito">${product.price}</p>
                <svg class="icon-close" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
                </svg>
            `;
            containerCartProducts.appendChild(cartProduct);
        });

        // Actualizar contador
        countProducts.textContent = cart.length;

        // Calcular total
        const total = cart.reduce((sum, product) => sum + parseFloat(product.price.replace('$', '')), 0);
        const totalElement = document.createElement('div');
        totalElement.classList.add('cart-total');
        totalElement.innerHTML = `
            <h3>Total:</h3>
            <p class="total-pagar">$${total.toFixed(2)}</p>
        `;
        containerCartProducts.appendChild(totalElement);

        // Eliminar productos
        document.querySelectorAll('.icon-close').forEach(icon => {
            icon.addEventListener('click', () => {
                const productTitle = icon.closest('.cart-product').querySelector('.titulo-producto-carrito').textContent;
                cart = cart.filter(product => product.title !== productTitle);
                updateCart();
            });
        });
    };

    // Mostrar/ocultar carrito
    btnCart.addEventListener('click', () => {
        containerCartProducts.classList.toggle('hidden-cart');
    });
});


// Slider Automático Pequeño
document.addEventListener('DOMContentLoaded', () => {
    const sliderTrack = document.querySelector('.slider-track');
    const slides = document.querySelectorAll('.slide');
    const prevBtn = document.querySelector('.prev');
    const nextBtn = document.querySelector('.next');
    let currentIndex = 0;
    const slideWidth = slides[0].clientWidth;

    // Clona el primer slide para efecto infinito
    sliderTrack.appendChild(slides[0].cloneNode(true));

    // Función para avanzar
    function nextSlide() {
        currentIndex = (currentIndex + 1) % slides.length;
        sliderTrack.style.transform = `translateX(-${currentIndex * slideWidth}px)`;
    }

    // Botones
    nextBtn.addEventListener('click', nextSlide);

    prevBtn.addEventListener('click', () => {
        currentIndex = (currentIndex - 1 + slides.length) % slides.length;
        sliderTrack.style.transform = `translateX(-${currentIndex * slideWidth}px)`;
    });

    // Cambio automático cada 3 segundos
    setInterval(nextSlide, 3000);
});
